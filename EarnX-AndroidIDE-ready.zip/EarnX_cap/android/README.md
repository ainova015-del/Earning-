# EarnX Android WebView wrapper

This optional sample shows the bridge required for AdMob rewarded ads. It is intentionally separate from the Firebase-hosted PWA.

1. Create an Android Studio app and copy these files into it.
2. Set your Firebase Hosting URL in `MainActivity.kt`.
3. Add your AdMob application ID to `AndroidManifest.xml` and your rewarded ad unit ID in `MainActivity.kt`.
4. Use Google's test rewarded ad unit during development.
5. Configure AdMob SSV to call the deployed `admobSsv` Cloud Function. The native callback is only UX; the server's signed SSV callback is what credits coins.
6. Before release, complete AdMob/Play policy, consent/privacy requirements and production app/ad-unit configuration.
