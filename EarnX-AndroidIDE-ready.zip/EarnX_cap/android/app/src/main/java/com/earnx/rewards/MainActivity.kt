package com.earnx.rewards

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewarded.ServerSideVerificationOptions
import com.google.android.gms.ads.LoadAdError

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var rewardedAd: RewardedAd? = null
    // Google's documented Android test rewarded ad unit. Replace only after production AdMob setup.
    private val adUnitId = "ca-app-pub-4750812054378687/4607222129"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            addJavascriptInterface(AdBridge(), "EarnXNativeAd")
            loadUrl("https://YOUR_PROJECT.web.app/earn.html")
        }
        setContentView(web)
        MobileAds.initialize(this) { loadRewarded() }
    }

    private fun loadRewarded() {
        RewardedAd.load(this, adUnitId, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) { rewardedAd = ad }
            override fun onAdFailedToLoad(error: LoadAdError) { rewardedAd = null }
        })
    }

    inner class AdBridge {
        @JavascriptInterface
        fun showRewardedAd(userId: String) {
            runOnUiThread {
                val ad = rewardedAd ?: run {
                    web.evaluateJavascript("window.__earnxAdRejected('Ad is not ready')", null)
                    loadRewarded(); return@runOnUiThread
                }
                rewardedAd = null
                if (userId.isBlank()) {
                    web.evaluateJavascript("window.__earnxAdRejected(\'Missing Firebase user ID\')", null)
                    loadRewarded()
                    return@runOnUiThread
                }
                val ssv = ServerSideVerificationOptions.Builder().setCustomData(userId).build()
                ad.setServerSideVerificationOptions(ssv)
                ad.show(this@MainActivity) {
                    // Do NOT modify Firestore here. This only resolves the UI promise.
                    web.evaluateJavascript("window.__earnxAdCompleted()", null)
                }
                ad.fullScreenContentCallback = object : com.google.android.gms.ads.FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() { loadRewarded() }
                }
            }
        }
    }
}
