import {auth} from './firebase.js';
import {GoogleAuthProvider, signInWithPopup, onAuthStateChanged, signOut} from 'https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js';
import {httpsCallable} from 'https://www.gstatic.com/firebasejs/12.1.0/firebase-functions.js';
import {functions} from './firebase.js';
const error=document.querySelector('#error'); const btn=document.querySelector('#googleBtn');
const params=new URLSearchParams(location.search); const referralCode=params.get('ref')||localStorage.getItem('earnx_ref')||''; if(referralCode)localStorage.setItem('earnx_ref',referralCode);
onAuthStateChanged(auth,u=>{if(u&&!location.pathname.endsWith('/login.html'))location.replace('/home.html');});
btn?.addEventListener('click',async()=>{error.textContent='';btn.disabled=true;btn.textContent='Signing in…';try{const provider=new GoogleAuthProvider();provider.setCustomParameters({prompt:'select_account'});await signInWithPopup(auth,provider);await httpsCallable(functions,'ensureUserProfile')({referralCode:localStorage.getItem('earnx_ref')||''});localStorage.removeItem('earnx_ref');location.replace('/home.html')}catch(e){console.error(e);error.textContent=e?.message||'Sign-in failed.';btn.disabled=false;btn.textContent='Continue with Google'}});
export async function logout(){await signOut(auth);location.replace('/login.html')}
